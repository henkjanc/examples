# REST framework tutorial

Source code for the [Django REST framework tutorial][tut].

[tut]: http://www.django-rest-framework.org/tutorial/1-serialization
